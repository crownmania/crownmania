// This file loads environment variables before any other modules
import dotenv from 'dotenv';
dotenv.config();
